var PRODUCTS=SITE.products;
function ok(p){return /^https?:\/\//.test(p.link||"")&&p.link.indexOf("REPLACE_ME")<0}
function para(t){return String(t||"").split(/\n\s*\n/).filter(function(s){return s.trim()}).map(function(s){return "<p>"+esc(s).replace(/\n/g,"<br>")+"</p>"}).join("")}
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})}
PRODUCTS.forEach(function(p,i){p.id="p"+i});
function find(id){return PRODUCTS.filter(function(p){return p.id===id})[0]}
var cart=[];try{cart=JSON.parse(localStorage.getItem("pnwcart")||"[]")}catch(e){}
cart=cart.filter(function(i){var p=find(i);return p&&!p.sold});
var cartD=document.getElementById("cart"),cBody=document.getElementById("cBody");
function save(){try{localStorage.setItem("pnwcart",JSON.stringify(cart))}catch(e){}document.getElementById("cartN").textContent=cart.length}
function drawCart(){
 var items=cart.map(find).filter(Boolean),total=0,h="";
 if(!items.length){cBody.innerHTML="<p>Your cart is empty.</p>";return}
 items.forEach(function(p){total+=p.price;h+='<div class="crow"><span>'+esc(p.name)+(p.price?" &ndash; $"+p.price:"")+'</span><span><a class="btn" href="'+esc(p.link)+'">Check out</a> <button class="lnk" data-rm="'+p.id+'">Remove</button></span></div>'});
 var body="Hi Colin, I'd like to buy:\n\n"+items.map(function(p){return "- "+p.name+(p.price?" ($"+p.price+")":"")}).join("\n")+"\n\nPlease send me one invoice.";
 if(items.length>1)h+='<p class="note">Secure checkout handles one piece at a time. To pay for everything at once, request a single invoice.</p>';
 h+='<p><a class="btn o" href="mailto:'+SITE.email+'?subject='+encodeURIComponent("Order request")+"&body="+encodeURIComponent(body)+'">Request one invoice</a></p>';
 cBody.innerHTML=h;
}
function openCart(){drawCart();if(!cartD.open)cartD.showModal()}
document.addEventListener("click",function(e){
 var t=e.target.closest("[data-add],[data-rm],#cartOpen,.xc");if(!t)return;
 if(t.dataset.add){if(cart.indexOf(t.dataset.add)<0){cart.push(t.dataset.add);save()}openCart()}
 else if(t.dataset.rm){cart=cart.filter(function(x){return x!==t.dataset.rm});var gal=document.getElementById("gal");
if(gal)gal.innerHTML=SITE.gallery.map(function(s){return '<img src="'+esc(s)+'" alt="Handmade glass" loading="lazy">'}).join("");
var pb=document.getElementById("pageBody");
if(pb){var pd=SITE.pages[document.body.dataset.page]||{text:"",images:[]};
 pb.innerHTML=para(pd.text)+pd.images.map(function(s){return '<img src="'+esc(s)+'" alt="'+esc(pd.title||"")+'" style="width:100%;margin:12px 0">'}).join("")}
save();drawCart()}
 else if(t.id==="cartOpen")openCart();else cartD.close();
});
var grid=document.getElementById("grid");
if(grid){
 var cat=document.body.dataset.cat,list=PRODUCTS.filter(function(p){return !cat||p.cat===cat});
 grid.innerHTML=list.length?list.map(function(p){
  return '<article class="card"><img src="'+esc(p.img)+'" alt="'+esc(p.name)+'" loading="lazy"><h3>'+esc(p.name)+'</h3><p class="pr">'+(p.price?"$"+p.price:"")+'</p><div class="row">'+(p.sold?'<a class="btn" aria-disabled="true">Sold</a>':(ok(p)?'<a class="btn" href="'+esc(p.link)+'">Buy now</a>':'<a class="btn" href="mailto:'+SITE.email+'?subject='+encodeURIComponent("Inquiry: "+p.name)+'">Inquire</a>')+'<button class="btn o" data-add="'+p.id+'">Add to cart</button>')+'</div></article>'
 }).join(""):"<p>No pieces in this category right now. Email colin@pnwglass.com to ask about new work.</p>";
}
var gal=document.getElementById("gal");
if(gal)gal.innerHTML=SITE.gallery.map(function(s){return '<img src="'+esc(s)+'" alt="Handmade glass" loading="lazy">'}).join("");
var pb=document.getElementById("pageBody");
if(pb){var pd=SITE.pages[document.body.dataset.page]||{text:"",images:[]};
 pb.innerHTML=para(pd.text)+pd.images.map(function(s){return '<img src="'+esc(s)+'" alt="'+esc(pd.title||"")+'" style="width:100%;margin:12px 0">'}).join("")}
save();