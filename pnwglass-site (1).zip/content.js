/* This file is written by admin.html. You can also edit it by hand. */
var SITE={
 "email": "colin@pnwglass.com",
 "categories": [
  "Votives",
  "Bowls",
  "Vessels",
  "Lighting",
  "Seasonal",
  "Ornaments",
  "Floats",
  "Garden Art"
 ],
 "products": [
  {
   "name": "Plum & Lime Votive",
   "cat": "Votives",
   "price": 0,
   "img": "images/votive-plum-lime.jpg",
   "link": "",
   "sold": false
  },
  {
   "name": "Berry & Violet Votive",
   "cat": "Votives",
   "price": 0,
   "img": "images/votive-berry-violet.jpg",
   "link": "",
   "sold": false
  },
  {
   "name": "Autumn Speckle Votive",
   "cat": "Votives",
   "price": 0,
   "img": "images/votive-autumn-speckle.jpg",
   "link": "",
   "sold": false
  },
  {
   "name": "Sunshine Yellow Votive",
   "cat": "Votives",
   "price": 0,
   "img": "images/votive-sunshine-yellow.jpg",
   "link": "",
   "sold": false
  },
  {
   "name": "Teal Swirl Votive",
   "cat": "Votives",
   "price": 0,
   "img": "images/votive-teal-swirl.jpg",
   "link": "",
   "sold": false
  },
  {
   "name": "Orchid & Lime Votive",
   "cat": "Votives",
   "price": 0,
   "img": "images/votive-orchid-lime.jpg",
   "link": "",
   "sold": false
  },
  {
   "name": "Milk White Votive",
   "cat": "Votives",
   "price": 0,
   "img": "images/votive-milk-white.jpg",
   "link": "",
   "sold": false
  },
  {
   "name": "Tangerine Votive",
   "cat": "Votives",
   "price": 0,
   "img": "images/votive-tangerine.jpg",
   "link": "",
   "sold": false
  },
  {
   "name": "Spring Meadow Votive",
   "cat": "Votives",
   "price": 0,
   "img": "images/votive-spring-meadow.jpg",
   "link": "",
   "sold": false
  },
  {
   "name": "Lime Green Votive",
   "cat": "Votives",
   "price": 0,
   "img": "images/votive-lime-green.jpg",
   "link": "",
   "sold": false
  },
  {
   "name": "Sea Glass & Amber Votive",
   "cat": "Votives",
   "price": 0,
   "img": "images/votive-sea-glass-amber.jpg",
   "link": "",
   "sold": false
  },
  {
   "name": "Emerald Votive",
   "cat": "Votives",
   "price": 0,
   "img": "images/votive-emerald.jpg",
   "link": "",
   "sold": false
  },
  {
   "name": "Orbiting Bodies",
   "cat": "Bowls",
   "price": 0,
   "img": "https://img1.wsimg.com/isteam/ip/7f890837-2257-48dd-829e-1d69d3fef527/iphone%20399.JPG/:/rs=w:900,cg:true",
   "link": "",
   "sold": false
  },
  {
   "name": "Vessel (replace with your product)",
   "cat": "Vessels",
   "price": 0,
   "img": "https://img1.wsimg.com/isteam/ip/7f890837-2257-48dd-829e-1d69d3fef527/B1CD4CF9-9996-422B-8456-24C479302F5B.jpeg/:/rs=w:900,cg:true",
   "link": "",
   "sold": false
  }
 ],
 "gallery": [
  "https://img1.wsimg.com/isteam/ip/7f890837-2257-48dd-829e-1d69d3fef527/IMG_8617.jpg/:/rs=w:600,cg:true",
  "https://img1.wsimg.com/isteam/ip/7f890837-2257-48dd-829e-1d69d3fef527/IMG_8621-_1_.jpg/:/rs=w:600,cg:true"
 ],
 "pages": {
  "about": {
   "title": "About",
   "text": "",
   "images": []
  },
  "bespoke-glass": {
   "title": "Bespoke Glass",
   "text": "",
   "images": []
  },
  "glass-restoration": {
   "title": "Glass Restoration",
   "text": "",
   "images": [
    "https://img1.wsimg.com/isteam/ip/7f890837-2257-48dd-829e-1d69d3fef527/E34BE361-F59C-49A2-B672-B6C382D90BBB.jpeg/:/rs=w:900,cg:true",
    "https://img1.wsimg.com/isteam/ip/7f890837-2257-48dd-829e-1d69d3fef527/BC293FFA-B4A9-40BC-9A93-7B31124D7530.jpeg/:/rs=w:900,cg:true",
    "https://img1.wsimg.com/isteam/ip/7f890837-2257-48dd-829e-1d69d3fef527/0643381B-496E-4440-97BA-9A7527684ED6.jpeg/:/rs=w:900,cg:true"
   ]
  }
 }
};
