var IMG="https://img1.wsimg.com/isteam/ip/7f890837-2257-48dd-829e-1d69d3fef527/";
function u(f,w){return IMG+f+"/:/rs=w:"+(w||900)+",cg:true"}
/* ===== EDIT YOUR PRODUCTS HERE (cat must match a category name: Votives, Bowls, Vessels, Lighting, Seasonal, Ornaments, Floats, Garden Art) =====
   price: number (0 hides the price) | link: your Stripe Payment Link | sold: true to show Sold */
var PRODUCTS=[
 {name:"Votive (replace with your product)",cat:"Votives",price:0,img:u("54DC6DC3-1FB5-44CF-88C0-F7C130A7718D.jpeg"),link:"https://buy.stripe.com/REPLACE_ME",sold:false},
 {name:"Orbiting Bodies",cat:"Bowls",price:0,img:u("iphone%20399.JPG"),link:"https://buy.stripe.com/REPLACE_ME",sold:false},
 {name:"Vessel (replace with your product)",cat:"Vessels",price:0,img:u("B1CD4CF9-9996-422B-8456-24C479302F5B.jpeg"),link:"https://buy.stripe.com/REPLACE_ME",sold:false}
];
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})}
PRODUCTS.forEach(function(p,i){p.id="p"+i});
function find(id){return PRODUCTS.filter(function(p){return p.id===id})[0]}
var cart=[];try{cart=JSON.parse(localStorage.getItem("pnwcart")||"[]")}catch(e){}
cart=cart.filter(function(i){var p=find(i);return p&&!p.sold});
var cartD=document.getElementById("cart"),cBody=document.getElementById("cBody");
function save(){try{localStorage.setItem("pnwcart",JSON.stringify(cart))}catch(e){}document.getElementById("cartN").textContent=cart.length}
function drawCart(){
 var items=cart.map(find).filter(Boolean),total=0,h="";
 if(!items.length){cBody.innerHTML="<p>Your cart is empty.</p>";return}
 items.forEach(function(p){total+=p.price;h+='<div class="crow"><span>'+esc(p.name)+(p.price?" &ndash; $"+p.price:"")+'</span><span><a class="btn" href="'+esc(p.link)+'">Check out</a> <button class="lnk" data-rm="'+p.id+'">Remove</button></span></div>'});
 var body="Hi Colin, I'd like to buy:\n\n"+items.map(function(p){return "- "+p.name+(p.price?" ($"+p.price+")":"")}).join("\n")+"\n\nPlease send me one invoice.";
 if(items.length>1)h+='<p class="note">Secure checkout handles one piece at a time. To pay for everything at once, request a single invoice.</p>';
 h+='<p><a class="btn o" href="mailto:colin@pnwglass.com?subject='+encodeURIComponent("Order request")+"&body="+encodeURIComponent(body)+'">Request one invoice</a></p>';
 cBody.innerHTML=h;
}
function openCart(){drawCart();if(!cartD.open)cartD.showModal()}
document.addEventListener("click",function(e){
 var t=e.target.closest("[data-add],[data-rm],#cartOpen,.xc");if(!t)return;
 if(t.dataset.add){if(cart.indexOf(t.dataset.add)<0){cart.push(t.dataset.add);save()}openCart()}
 else if(t.dataset.rm){cart=cart.filter(function(x){return x!==t.dataset.rm});save();drawCart()}
 else if(t.id==="cartOpen")openCart();else cartD.close();
});
var grid=document.getElementById("grid");
if(grid){
 var cat=document.body.dataset.cat,list=PRODUCTS.filter(function(p){return !cat||p.cat===cat});
 grid.innerHTML=list.length?list.map(function(p){
  return '<article class="card"><img src="'+esc(p.img)+'" alt="'+esc(p.name)+'" loading="lazy"><h3>'+esc(p.name)+'</h3><p class="pr">'+(p.price?"$"+p.price:"")+'</p><div class="row">'+(p.sold?'<a class="btn" aria-disabled="true">Sold</a>':'<a class="btn" href="'+esc(p.link)+'">Buy now</a><button class="btn o" data-add="'+p.id+'">Add to cart</button>')+'</div></article>'
 }).join(""):"<p>No pieces in this category right now. Email colin@pnwglass.com to ask about new work.</p>";
}
save();